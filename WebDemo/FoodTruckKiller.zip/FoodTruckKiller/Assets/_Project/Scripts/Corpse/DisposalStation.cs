using FoodTruckKiller.Core.Events;
using FoodTruckKiller.Interaction;
using FoodTruckKiller.Inventory;
using FoodTruckKiller.Player;
using UnityEngine;

namespace FoodTruckKiller.Corpse
{
    /// <summary>
    /// 尸体处理站：交互后按 DisposalMethod 处理玩家当前搬运的尸体。
    /// 绞肉可产出人肉食材加入背包。
    /// </summary>
    public class DisposalStation : MonoBehaviour, IInteractable
    {
        /// <summary>处理方式。</summary>
        public DisposalMethod method = DisposalMethod.Grind;

        /// <summary>处理时长（秒）。</summary>
        public float processDuration = 3f;

        /// <summary>交互提示。</summary>
        [SerializeField] private string promptName = "处理尸体";

        /// <summary>绞肉产出的人肉食材 id。</summary>
        public string humanMeatIngredientId = "human_meat";

        /// <summary>是否正在处理。</summary>
        public bool IsProcessing { get; private set; }

        /// <summary>
        /// 玩家交互。
        /// </summary>
        public void OnInteract(PlayerController player)
        {
            if (IsProcessing) return;
            // 查找玩家正在搬运的尸体。
            Corpse target = FindCarriedCorpse(player);
            if (target == null) return;
            ProcessCorpse(target);
        }

        /// <summary>
        /// 返回交互提示。
        /// </summary>
        public string GetPromptName()
        {
            return promptName;
        }

        /// <summary>
        /// 查找玩家正在搬运的尸体（基于 CorpseManager 列表）。
        /// </summary>
        private Corpse FindCarriedCorpse(PlayerController player)
        {
            if (CorpseManager.Instance == null) return null;
            foreach (var c in CorpseManager.Instance.ActiveCorpses)
            {
                if (c != null && c.IsCarried) return c;
            }
            return null;
        }

        /// <summary>
        /// 处理尸体。
        /// </summary>
        private void ProcessCorpse(Corpse corpse)
        {
            IsProcessing = true;
            // 模拟延时处理。
            Invoke(nameof(FinishProcess), processDuration);
            _pending = corpse;
        }

        private Corpse _pending;

        /// <summary>完成处理回调。</summary>
        private void FinishProcess()
        {
            if (_pending == null)
            {
                IsProcessing = false;
                return;
            }

            switch (method)
            {
                case DisposalMethod.Grind:
                    // 产出人肉食材。
                    if (InventorySystem.Instance != null)
                        InventorySystem.Instance.Add(humanMeatIngredientId, 2);
                    break;
                case DisposalMethod.Dump:
                    // 抛尸有概率被发现。
                    if (Random.value < 0.3f)
                        GameEvents.OnCorpseFound?.Raise();
                    break;
                case DisposalMethod.Freeze:
                    // 冷冻：无特殊产出，仅延后腐败。
                    break;
                case DisposalMethod.Dissolve:
                    // 溶解：完全无残留。
                    break;
            }

            _pending.MarkDisposed();
            _pending = null;
            IsProcessing = false;
        }
    }
}
