using UnityEngine;
using FoodTruckKiller.Core.Events;
using FoodTruckKiller.Core.DataLoader;
using FoodTruckKiller.Audio;
using FoodTruckKiller.Economy;
using FoodTruckKiller.Cooking;
using FoodTruckKiller.Customer;
using FoodTruckKiller.Player;

namespace FoodTruckKiller.GameManager
{
    /// <summary>
    /// 场景引导器：场景启动时按依赖顺序创建并初始化所有子系统。
    /// <para>挂载在场景中的空 GameObject 上即可自动完成 M1 经营循环的全部布线，
    /// 无需 Inspector 注入（沙箱无编辑器亦可运行）。</para>
    /// <para>Awake 顺序：</para>
    /// <list type="number">
    /// <item><see cref="GameEvents.Init"/> —— 创建所有事件实例（其他系统 OnEnable 注册依赖于此）</item>
    /// <item><see cref="JsonDataLoader.LoadAll"/> —— 加载 JSON 数据（GameManager/EconomyManager 依赖配置）</item>
    /// <item>AudioManager（单例，AudioFeedbackBinder 依赖）</item>
    /// <item>GameManager / EconomyManager（单例，注册 OnDayEnd/OnOrderServed）</item>
    /// <item>DayTimeController / ObjectiveTracker（注册/触发事件）</item>
    /// <item>CustomerSpawner / CookingController（单例）+ CookingStation × 4</item>
    /// <item>AudioFeedbackBinder（依赖 AudioManager + GameEvents）</item>
    /// <item>Player（PlayerController + PlayerMotor + PlayerInteractor + CarryController）</item>
    /// </list>
    /// <para>Start 阶段调用 <see cref="GameManager.StartGame"/> 进入 Playing 状态。</para>
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public class SceneBootstrapper : MonoBehaviour
    {
        private void Awake()
        {
            // 1. 事件聚合（必须最先：其他系统 OnEnable 会注册）
            GameEvents.Init();

            // 2. 数据加载（EconomyManager/ObjectiveTracker 依赖配置）
            JsonDataLoader.LoadAll();

            // 3. AudioManager（单例，AudioFeedbackBinder 依赖）
            var audioGo = new GameObject("[AudioManager]");
            audioGo.AddComponent<AudioManager>();

            // 4. GameManager / EconomyManager（单例）
            var gameMgrGo = new GameObject("[GameManager]");
            var gameMgr = gameMgrGo.AddComponent<GameManager>();

            var econGo = new GameObject("[EconomyManager]");
            var econMgr = econGo.AddComponent<EconomyManager>();
            gameMgr.AssignEconomyManager(econMgr);

            // 5. DayTimeController / ObjectiveTracker
            var dayGo = new GameObject("[DayTimeController]");
            var dayCtl = dayGo.AddComponent<DayTimeController>();
            gameMgr.AssignDayTimeController(dayCtl);

            var objGo = new GameObject("[ObjectiveTracker]");
            var objTracker = objGo.AddComponent<ObjectiveTracker>();
            gameMgr.AssignObjectiveTracker(objTracker);

            // 6. CustomerSpawner / CookingController + CookingStation × 4
            var queueGo = new GameObject("[QueueManager]");
            queueGo.AddComponent<QueueManager>();

            var spawnerGo = new GameObject("[CustomerSpawner]");
            var spawner = spawnerGo.AddComponent<CustomerSpawner>();
            if (JsonDataLoader.CustomerProfiles != null)
                spawner.profiles = JsonDataLoader.CustomerProfiles;
            if (JsonDataLoader.Recipes != null)
                spawner.availableRecipes = JsonDataLoader.Recipes;
            gameMgr.AssignCustomerSpawner(spawner);

            var cookGo = new GameObject("[CookingController]");
            var cookCtl = cookGo.AddComponent<CookingController>();
            gameMgr.AssignCookingController(cookCtl);

            CreateCookingStation(CookingWorkstation.Chop, "ChopStation", new Vector3(-2f, -1f, 0f));
            CreateCookingStation(CookingWorkstation.Grill, "GrillStation", new Vector3(0f, -1f, 0f));
            CreateCookingStation(CookingWorkstation.Assemble, "AssembleStation", new Vector3(2f, -1f, 0f));
            CreateCookingStation(CookingWorkstation.Serve, "ServeStation", new Vector3(0f, 1f, 0f));

            // 7. AudioFeedbackBinder（依赖 AudioManager + GameEvents）
            var binderGo = new GameObject("[AudioFeedbackBinder]");
            binderGo.AddComponent<AudioFeedbackBinder>();
            binderGo.AddComponent<HitStop>();

            // 主摄像机 + ScreenShake（AudioFeedbackBinder.OnCustomerDied 需要 Camera.main）
            var camGo = new GameObject("[MainCamera]");
            var cam = camGo.AddComponent<Camera>();
            cam.tag = "MainCamera";
            camGo.AddComponent<ScreenShake>();

            // 8. Player
            CreatePlayer(new Vector3(0f, 0f, 0f));
        }

        private void Start()
        {
            // 所有子系统已就绪，进入 Playing 状态。
            if (GameManager.Instance != null)
                GameManager.Instance.StartGame();
        }

        // ---- 辅助：创建烹饪工作位 ----

        private static CookingStation CreateCookingStation(CookingWorkstation ws, string name, Vector3 pos)
        {
            var go = new GameObject(name);
            go.transform.position = pos;
            // 添加触发器碰撞体，使 PlayerInteractor.OverlapCircle 能检测到
            var col = go.AddComponent<CircleCollider2D>();
            col.radius = 0.6f;
            col.isTrigger = true;
            var station = go.AddComponent<CookingStation>();
            station.workstation = ws;
            return station;
        }

        // ---- 辅助：创建玩家 ----

        private static GameObject CreatePlayer(Vector3 pos)
        {
            var go = new GameObject("[Player]");
            go.transform.position = pos;
            // 顺序：Rigidbody2D → PlayerMotor → PlayerController → PlayerInteractor → CarryController
            // 由于 AddComponent 立即触发 Awake，先添加的组件无法 Get 到后添加的组件，
            // 故全部添加完毕后调用 RebindDependencies() 重新解析依赖。
            go.AddComponent<Rigidbody2D>();
            go.AddComponent<PlayerMotor>();
            var controller = go.AddComponent<PlayerController>();
            var interactor = go.AddComponent<PlayerInteractor>();
            go.AddComponent<CarryController>();
            controller.RebindDependencies();
            interactor.RebindDependencies();
            // 沙箱无 Layer 配置：检测所有层，半径 0.6
            interactor.ConfigureDetection(~0, 0.6f);
            return go;
        }
    }
}
