using FoodTruckKiller.Core.Events;
using FoodTruckKiller.Corpse;
using FoodTruckKiller.Customer;
using FoodTruckKiller.Detection;
using UnityEngine;

namespace FoodTruckKiller.Assassination
{
    /// <summary>
    /// 击杀执行器：按 KillMethodData 执行击杀，生成尸体，触发 GameEvent。
    /// </summary>
    public class KillExecutor : MonoBehaviour
    {
        /// <summary>尸体预制体（沙箱无编辑器时可为空，运行时生成空 GameObject）。</summary>
        [SerializeField] private GameObject corpsePrefab;

        /// <summary>
        /// 执行击杀。
        /// </summary>
        /// <param name="victim">被击杀的顾客 AI。</param>
        /// <param name="method">击杀方式数据。</param>
        public void Execute(CustomerAI victim, KillMethodData method)
        {
            if (victim == null || method == null) return;

            // 标记顾客死亡。
            victim.MarkDead();

            // 生成尸体。
            SpawnCorpse(victim.transform.position, method);

            // 累加警戒值（通过 AlertSystem）。
            if (AlertSystem.Instance != null)
                AlertSystem.Instance.AddAlert(method.noiseRadius * 2f);

            // 留下证据（通过 EvidenceTracker）。
            if (EvidenceTracker.Instance != null)
                EvidenceTracker.Instance.LeaveEvidence(victim.transform.position, method.evidenceType);

            // 触发通用顾客死亡事件（静态 GameEvents）。
            GameEvents.OnCustomerDied?.Raise();

            // 若为目标，触发目标击杀事件。
            if (victim.Profile != null && victim.Profile.type == CustomerType.Target)
            {
                GameEvents.OnTargetKilled?.Raise();
            }
        }

        /// <summary>
        /// 在指定位置生成尸体。
        /// </summary>
        private void SpawnCorpse(Vector3 pos, KillMethodData method)
        {
            GameObject go;
            if (corpsePrefab != null)
            {
                go = Instantiate(corpsePrefab, pos, Quaternion.identity);
            }
            else
            {
                // 沙箱无编辑器：运行时构造尸体 GameObject。
                go = new GameObject("Corpse_Runtime");
                go.transform.position = pos;
                go.AddComponent<BoxCollider2D>();
            }
            var corpse = go.GetComponent<Corpse>() ?? go.AddComponent<Corpse>();
            corpse.Initialize(method.evidenceType);
        }
    }
}
